package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.QuestionItem
import com.example.model.QuestionType
import com.example.ui.theme.AcademicGold
import com.example.ui.theme.AcademicNavy
import com.example.ui.theme.AcademicNavyLight
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.DeepEspresso
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedBg
import com.example.ui.theme.PaperBorder
import com.example.ui.theme.StoneBackground2
import com.example.ui.theme.TextSecondary

val SINHALA_LETTERS = listOf("අ", "ආ", "ඇ", "ඈ", "ඉ", "ඊ", "උ", "ඌ")

@Composable
fun QuestionCard(
    item: QuestionItem,
    displayIndex: Int,
    onUpdate: (QuestionItem) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (item.isSection) {
        // Section Header Card
        Card(
            modifier = modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = AcademicNavy)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                BasicTextField(
                    value = item.sectionTitle,
                    onValueChange = { onUpdate(item.copy(sectionTitle = it)) },
                    textStyle = TextStyle(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.Serif
                    ),
                    modifier = Modifier.weight(1f)
                )

                Row {
                    IconButton(onClick = onMoveUp, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up", tint = Color.White)
                    }
                    IconButton(onClick = onMoveDown, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down", tint = Color.White)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF8A80))
                    }
                }
            }
        }
        return
    }

    // Standard Question Card
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, PaperBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Card Header
            Surface(
                color = StoneBackground2.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Question Number badge
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(AcademicNavy),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = displayIndex.toString(),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Type Badge
                    Surface(
                        color = AcademicNavyLight.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "${item.type.icon} ${item.type.titleSi}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AcademicNavy,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Marks input
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = "ලකුණු:", fontSize = 11.sp, color = TextSecondary)
                        BasicTextField(
                            value = item.marks.toString(),
                            onValueChange = {
                                val parsed = it.toIntOrNull() ?: 0
                                onUpdate(item.copy(marks = parsed.coerceIn(0, 50)))
                            },
                            textStyle = TextStyle(
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = AcademicNavy
                            ),
                            modifier = Modifier
                                .width(28.dp)
                                .border(1.dp, PaperBorder, RoundedCornerShape(4.dp))
                                .padding(2.dp)
                        )
                    }

                    // Action buttons
                    IconButton(onClick = onDuplicate, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(15.dp), tint = TextSecondary)
                    }
                    IconButton(onClick = onMoveUp, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up", modifier = Modifier.size(18.dp), tint = TextSecondary)
                    }
                    IconButton(onClick = onMoveDown, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down", modifier = Modifier.size(18.dp), tint = TextSecondary)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp), tint = ErrorRed)
                    }
                }
            }

            // Question Body
            Column(modifier = Modifier.padding(12.dp)) {
                // Question Text Field
                BasicTextField(
                    value = item.question,
                    onValueChange = { onUpdate(item.copy(question = it)) },
                    textStyle = TextStyle(
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = DeepEspresso,
                        lineHeight = 20.sp,
                        fontFamily = FontFamily.Serif
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { innerTextField ->
                        Box {
                            if (item.question.isEmpty()) {
                                Text(
                                    text = "ප්‍රශ්නය මෙහි සටහන් කරන්න...",
                                    fontSize = 14.sp,
                                    color = Color.Gray,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Type-specific content
                when (item.type) {
                    QuestionType.MCQ -> {
                        MCQContent(
                            options = item.options,
                            correctOption = item.correctOption,
                            onOptionChange = { idx, txt ->
                                val newOptions = item.options.toMutableList()
                                newOptions[idx] = txt
                                onUpdate(item.copy(options = newOptions))
                            },
                            onMarkCorrect = { idx ->
                                val newCorrect = if (item.correctOption == idx) null else idx
                                onUpdate(item.copy(correctOption = newCorrect))
                            },
                            onAddOption = {
                                if (item.options.size < 6) {
                                    onUpdate(item.copy(options = item.options + ""))
                                }
                            },
                            onRemoveOption = { idx ->
                                if (item.options.size > 2) {
                                    val newOptions = item.options.toMutableList().apply { removeAt(idx) }
                                    val newCorrect = if (item.correctOption == idx) null
                                    else if (item.correctOption != null && item.correctOption > idx) item.correctOption - 1
                                    else item.correctOption
                                    onUpdate(item.copy(options = newOptions, correctOption = newCorrect))
                                }
                            }
                        )
                    }

                    QuestionType.SHORT -> {
                        LinedAnswerContent(
                            linesCount = item.lines,
                            onLinesChange = { onUpdate(item.copy(lines = it)) },
                            minLines = 1,
                            maxLines = 8
                        )
                    }

                    QuestionType.ESSAY -> {
                        LinedAnswerContent(
                            linesCount = item.lines,
                            onLinesChange = { onUpdate(item.copy(lines = it)) },
                            minLines = 5,
                            maxLines = 25
                        )
                    }

                    QuestionType.FILL -> {
                        Text(
                            text = "හිස්තැන් සඳහා ප්‍රශ්න පාඨය තුළ '________' (යටි ඉරි) භාවිතා කරන්න.",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280)
                        )
                    }

                    QuestionType.MATCH -> {
                        MatchContent(
                            leftItems = item.matchLeft,
                            rightItems = item.matchRight,
                            onLeftChange = { idx, txt ->
                                val list = item.matchLeft.toMutableList().apply { this[idx] = txt }
                                onUpdate(item.copy(matchLeft = list))
                            },
                            onRightChange = { idx, txt ->
                                val list = item.matchRight.toMutableList().apply { this[idx] = txt }
                                onUpdate(item.copy(matchRight = list))
                            }
                        )
                    }

                    QuestionType.TRUE_FALSE -> {
                        TrueFalseContent(
                            statements = item.statements,
                            answers = item.tfAnswers,
                            onStatementChange = { idx, txt ->
                                val list = item.statements.toMutableList().apply { this[idx] = txt }
                                onUpdate(item.copy(statements = list))
                            },
                            onAnswerChange = { idx, ans ->
                                val list = item.tfAnswers.toMutableList().apply { this[idx] = ans }
                                onUpdate(item.copy(tfAnswers = list))
                            },
                            onAddStatement = {
                                onUpdate(item.copy(
                                    statements = item.statements + "",
                                    tfAnswers = item.tfAnswers + null
                                ))
                            }
                        )
                    }

                    QuestionType.DRAW -> {
                        DrawingCanvas(
                            strokes = item.strokes,
                            onStrokesChanged = { onUpdate(item.copy(strokes = it)) }
                        )
                    }

                    QuestionType.IMAGE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .border(1.dp, PaperBorder, RoundedCornerShape(8.dp))
                                .background(StoneBackground2),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "රූප සටහන / රූපය අමුණා ඇත",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MCQContent(
    options: List<String>,
    correctOption: Int?,
    onOptionChange: (Int, String) -> Unit,
    onMarkCorrect: (Int) -> Unit,
    onAddOption: () -> Unit,
    onRemoveOption: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEachIndexed { index, opt ->
            val isCorrect = correctOption == index
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (isCorrect) CorrectGreenBg else Color(0xFFF9FAFB),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isCorrect) CorrectGreen else Color(0xFFE5E7EB)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(if (isCorrect) CorrectGreen else AcademicNavy),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = SINHALA_LETTERS.getOrElse(index) { (index + 1).toString() },
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    BasicTextField(
                        value = opt,
                        onValueChange = { onOptionChange(index, it) },
                        textStyle = TextStyle(fontSize = 13.sp, color = DeepEspresso),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            if (opt.isEmpty()) {
                                Text("විකල්පය ${SINHALA_LETTERS.getOrElse(index) { "" }}...", fontSize = 12.sp, color = Color.Gray)
                            }
                            inner()
                        }
                    )

                    // Mark correct button
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isCorrect) CorrectGreen else Color.White,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isCorrect) CorrectGreen else PaperBorder
                        ),
                        modifier = Modifier
                            .clickable { onMarkCorrect(index) }
                            .padding(end = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isCorrect) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                            }
                            Text(
                                text = if (isCorrect) "නිවැරදියි" else "සලකුණු කරන්න",
                                fontSize = 10.sp,
                                color = if (isCorrect) Color.White else TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    if (options.size > 2) {
                        IconButton(onClick = { onRemoveOption(index) }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(12.dp), tint = ErrorRed)
                        }
                    }
                }
            }
        }

        if (options.size < 6) {
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color.Transparent,
                border = androidx.compose.foundation.BorderStroke(1.dp, AcademicNavy.copy(alpha = 0.5f)),
                modifier = Modifier
                    .clickable { onAddOption() }
                    .padding(top = 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = AcademicNavy, modifier = Modifier.size(14.dp))
                    Text(text = "විකල්පයක් එක් කරන්න", fontSize = 11.sp, color = AcademicNavy, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun LinedAnswerContent(
    linesCount: Int,
    onLinesChange: (Int) -> Unit,
    minLines: Int,
    maxLines: Int
) {
    Column {
        // Draw dashed lines
        for (i in 0 until linesCount) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp)
                    .drawBehind {
                        val strokeWidth = 1.dp.toPx()
                        val y = size.height - strokeWidth
                        drawLine(
                            color = Color(0xFFC0BFBE),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = strokeWidth,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                        )
                    }
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "පේළි ගණන: $linesCount", fontSize = 11.sp, color = TextSecondary)
            Slider(
                value = linesCount.toFloat(),
                onValueChange = { onLinesChange(it.toInt()) },
                valueRange = minLines.toFloat()..maxLines.toFloat(),
                steps = maxLines - minLines - 1,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MatchContent(
    leftItems: List<String>,
    rightItems: List<String>,
    onLeftChange: (Int, String) -> Unit,
    onRightChange: (Int, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "A තීරය", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AcademicNavy)
            Text(text = "B තීරය", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AcademicGold)
        }
        Spacer(modifier = Modifier.height(4.dp))

        leftItems.indices.forEach { i ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Column A item
                Surface(
                    color = StoneBackground2,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "${i + 1}. ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        BasicTextField(
                            value = leftItems.getOrElse(i) { "" },
                            onValueChange = { onLeftChange(i, it) },
                            textStyle = TextStyle(fontSize = 12.sp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Answer connection line
                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .height(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = ".....", color = Color.Gray, fontSize = 12.sp)
                }

                // Column B item
                Surface(
                    color = StoneBackground2,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    val rightLabel = listOf("A", "B", "C", "D", "E").getOrElse(i) { (i + 1).toString() }
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "($rightLabel) ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF854D0E))
                        BasicTextField(
                            value = rightItems.getOrElse(i) { "" },
                            onValueChange = { onRightChange(i, it) },
                            textStyle = TextStyle(fontSize = 12.sp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TrueFalseContent(
    statements: List<String>,
    answers: List<Boolean?>,
    onStatementChange: (Int, String) -> Unit,
    onAnswerChange: (Int, Boolean?) -> Unit,
    onAddStatement: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        statements.forEachIndexed { index, stmt ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StoneBackground2.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "${index + 1}. ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                BasicTextField(
                    value = stmt,
                    onValueChange = { onStatementChange(index, it) },
                    textStyle = TextStyle(fontSize = 12.sp, color = DeepEspresso),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        if (stmt.isEmpty()) Text("ප්‍රකාශය ඇතුළත් කරන්න...", fontSize = 11.sp, color = Color.Gray)
                        inner()
                    }
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    val ans = answers.getOrElse(index) { null }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (ans == true) CorrectGreenBg else Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (ans == true) CorrectGreen else PaperBorder),
                        modifier = Modifier.clickable { onAnswerChange(index, if (ans == true) null else true) }
                    ) {
                        Text(
                            text = "✅ ඇත",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (ans == true) CorrectGreen else TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (ans == false) ErrorRedBg else Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (ans == false) ErrorRed else PaperBorder),
                        modifier = Modifier.clickable { onAnswerChange(index, if (ans == false) null else false) }
                    ) {
                        Text(
                            text = "❌ නැත",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (ans == false) ErrorRed else TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        if (statements.size < 6) {
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color.Transparent,
                border = androidx.compose.foundation.BorderStroke(1.dp, AcademicNavy.copy(alpha = 0.5f)),
                modifier = Modifier.clickable { onAddStatement() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = AcademicNavy, modifier = Modifier.size(14.dp))
                    Text(text = "ප්‍රකාශයක් එක් කරන්න", fontSize = 11.sp, color = AcademicNavy)
                }
            }
        }
    }
}
