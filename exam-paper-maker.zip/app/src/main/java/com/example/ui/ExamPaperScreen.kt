package com.example.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ExamMetadata
import com.example.model.LogoHeaderStyle
import com.example.model.QuestionItem
import com.example.model.QuestionType
import com.example.ui.components.QuestionCard
import com.example.ui.components.SchoolHeaderView
import com.example.ui.components.StudentInfoView
import com.example.ui.dialogs.ClearAnswersDialog
import com.example.ui.dialogs.SchoolBrandingDialog
import com.example.ui.theme.AcademicGold
import com.example.ui.theme.AcademicNavy
import com.example.ui.theme.AcademicNavyDark
import com.example.ui.theme.AcademicNavyLight
import com.example.ui.theme.DeepEspresso
import com.example.ui.theme.PaperBackground
import com.example.ui.theme.PaperBorder
import com.example.ui.theme.StoneBackground
import com.example.ui.theme.StoneBackground2
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExamPaperScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var showA4Preview by remember { mutableStateOf(false) }
    var showBrandingDialog by remember { mutableStateOf(false) }
    var showClearAnswersDialog by remember { mutableStateOf(false) }
    var showAddQuestionSheet by remember { mutableStateOf(false) }

    var metadata by remember { mutableStateOf(ExamMetadata()) }

    // Initial default scholarship exam paper content matching the provided template
    val questions = remember {
        mutableStateListOf(
            QuestionItem(
                id = "sec_1",
                isSection = true,
                sectionTitle = "🔢 I කොටස - ගණිතය හා බුද්ධි පරීක්ෂණය"
            ),
            QuestionItem(
                id = "q_1",
                number = 1,
                type = QuestionType.MCQ,
                question = "1 සිට 100 දක්වා ඇති ඔත්තේ සංඛ්‍යා ගණන කීයද?",
                marks = 2,
                options = listOf("48", "49", "50", "51"),
                correctOption = 2
            ),
            QuestionItem(
                id = "q_2",
                number = 2,
                type = QuestionType.SHORT,
                question = "72 × 8 හි අගය සොයා පිළිතුර ලියන්න.",
                marks = 3,
                lines = 3
            ),
            QuestionItem(
                id = "q_3",
                number = 3,
                type = QuestionType.ESSAY,
                question = "ශ්‍රී ලංකාවේ ස්වාභාවික පරිසරය හා වනජීවීන් සුරැකීම පිළිබඳව ඔබ දන්නා කරුණු 5ක් ලියන්න.",
                marks = 5,
                lines = 6
            ),
            QuestionItem(
                id = "sec_2",
                isSection = true,
                sectionTitle = "🌿 II කොටස - සිංහල හා පරිසරය"
            ),
            QuestionItem(
                id = "q_4",
                number = 4,
                type = QuestionType.FILL,
                question = "ශ්‍රී ලංකාවේ ජාතික ගස ________ වේ. ජාතික මල ________ වේ.",
                marks = 2
            ),
            QuestionItem(
                id = "q_5",
                number = 5,
                type = QuestionType.MATCH,
                question = "A තීරයේ ඇති සතුන් හා පක්ෂීන් B තීරයේ නිල නාමයන් සමඟ ගළපන්න.",
                marks = 4,
                matchLeft = listOf("ඇතුන්", "නෙළුම් මල", "වලි කුකුළා", "නා ගස"),
                matchRight = listOf("ජාතික සත්ත්වයා", "ජාතික මල", "ජාතික පක්ෂියා", "ජාතික වෘක්ෂය")
            ),
            QuestionItem(
                id = "q_6",
                number = 6,
                type = QuestionType.TRUE_FALSE,
                question = "පහත ප්‍රකාශ නිවැරදි නම් 'ඇත' ද, වැරදි නම් 'නැත' ද සලකුණු කරන්න.",
                marks = 3,
                statements = listOf(
                    "ශ්‍රී ලංකාව ඉන්දියන් සාගරයේ පිහිටි දූපතකි.",
                    "ශ්‍රී ලංකාවේ අගනුවර යාපනය වේ.",
                    "ශ්‍රී ලංකාවේ උසම කන්ද පිදුරුතලාගල කන්ද වේ."
                ),
                tfAnswers = listOf(true, false, true)
            ),
            QuestionItem(
                id = "q_7",
                number = 7,
                type = QuestionType.DRAW,
                question = "සමචතුරස්‍රයක් ඇඳ එහි සමමිතික අක්ෂ සලකුණු කරන්න.",
                marks = 4
            )
        )
    }

    // Statistics computation
    val totalQuestions by remember {
        derivedStateOf { questions.count { !it.isSection } }
    }
    val totalMarksCalculated by remember {
        derivedStateOf { questions.filter { !it.isSection }.sumOf { it.marks } }
    }
    val mcqCount by remember {
        derivedStateOf { questions.count { it.type == QuestionType.MCQ } }
    }

    if (showA4Preview) {
        A4PreviewScreen(
            metadata = metadata,
            questions = questions,
            onBack = { showA4Preview = false }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Prominent Brand Logo badge in the app bar!
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .shadow(3.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(1.5.dp, AcademicGold, CircleShape)
                                .clickable { showBrandingDialog = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.app_logo_crest),
                                contentDescription = "School Logo",
                                modifier = Modifier
                                    .size(30.dp)
                                    .testTag("app_bar_logo"),
                                contentScale = ContentScale.Fit
                            )
                        }

                        Column {
                            Text(
                                text = "5 ශ්‍රේණිය ශිෂ්‍යත්ව ප්‍රශ්නපත්‍රය",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = metadata.schoolName,
                                fontSize = 11.sp,
                                color = AcademicGold
                            )
                        }
                    }
                },
                actions = {
                    // School Branding & Logo trigger
                    IconButton(
                        onClick = { showBrandingDialog = true },
                        modifier = Modifier.testTag("open_branding_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = "School & Logo Branding",
                            tint = AcademicGold
                        )
                    }

                    // Clear answers button
                    IconButton(onClick = { showClearAnswersDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.CleaningServices,
                            contentDescription = "Clear Answers",
                            tint = Color.White
                        )
                    }

                    // A4 View / Print button
                    IconButton(
                        onClick = { showA4Preview = true },
                        modifier = Modifier.testTag("open_a4_preview_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "A4 Preview & Print",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AcademicNavy,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            Surface(
                color = AcademicNavyDark,
                shadowElevation = 8.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Stats Bar
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatBadge(label = "ප්‍රශ්න", count = totalQuestions)
                        StatBadge(label = "ලකුණු", count = totalMarksCalculated)
                        StatBadge(label = "MCQ", count = mcqCount)
                    }

                    // Add question button
                    Button(
                        onClick = { showAddQuestionSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AcademicGold),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("add_question_fab")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Question",
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "ප්‍රශ්නයක් එක් කරන්න",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        },
        containerColor = StoneBackground
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // School Header with LOGO Integration
            item(key = "header") {
                SchoolHeaderView(
                    metadata = metadata,
                    onUpdateMetadata = { metadata = it },
                    onOpenBrandingDialog = { showBrandingDialog = true }
                )
            }

            // Student Information & Instructions
            item(key = "student_info") {
                StudentInfoView(
                    metadata = metadata,
                    onUpdateMetadata = { metadata = it }
                )
            }

            // Quick Subject presets row
            item(key = "subject_presets") {
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "පාඩම් කොටස් (Quick Section Add):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AcademicNavy
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SubjectChip(title = "🔢 I කොටස - ගණිතය") {
                                questions.add(QuestionItem(id = "sec_${System.currentTimeMillis()}", isSection = true, sectionTitle = "🔢 I කොටස - ගණිතය"))
                            }
                            SubjectChip(title = "🔤 II කොටස - සිංහල") {
                                questions.add(QuestionItem(id = "sec_${System.currentTimeMillis()}", isSection = true, sectionTitle = "🔤 II කොටස - සිංහල"))
                            }
                            SubjectChip(title = "🔠 III කොටස - English") {
                                questions.add(QuestionItem(id = "sec_${System.currentTimeMillis()}", isSection = true, sectionTitle = "🔠 III කොටස - English"))
                            }
                            SubjectChip(title = "🌿 IV කොටස - පරිසරය") {
                                questions.add(QuestionItem(id = "sec_${System.currentTimeMillis()}", isSection = true, sectionTitle = "🌿 IV කොටස - පරිසරය"))
                            }
                        }
                    }
                }
            }

            // Questions list
            itemsIndexed(
                items = questions,
                key = { _, item -> item.id }
            ) { index, item ->
                // Calculate display question number excluding sections
                val displayIndex = if (item.isSection) 0 else {
                    questions.take(index + 1).count { !it.isSection }
                }

                QuestionCard(
                    item = item,
                    displayIndex = displayIndex,
                    onUpdate = { updated ->
                        val targetIndex = questions.indexOfFirst { it.id == updated.id }
                        if (targetIndex != -1) {
                            questions[targetIndex] = updated
                        }
                    },
                    onMoveUp = {
                        if (index > 0) {
                            val temp = questions[index]
                            questions[index] = questions[index - 1]
                            questions[index - 1] = temp
                        }
                    },
                    onMoveDown = {
                        if (index < questions.size - 1) {
                            val temp = questions[index]
                            questions[index] = questions[index + 1]
                            questions[index + 1] = temp
                        }
                    },
                    onDuplicate = {
                        val newItem = item.copy(id = "q_${System.currentTimeMillis()}")
                        questions.add(index + 1, newItem)
                    },
                    onDelete = {
                        questions.removeAt(index)
                    }
                )
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Add Question Bottom Sheet
    if (showAddQuestionSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddQuestionSheet = false },
            sheetState = rememberModalBottomSheetState()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = "ප්‍රශ්න වර්ගයක් තෝරන්න (Select Question Type)",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AcademicNavy
                )
                Spacer(modifier = Modifier.height(14.dp))

                QuestionType.entries.forEach { type ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                val newItem = QuestionItem(
                                    id = "q_${System.currentTimeMillis()}",
                                    type = type,
                                    marks = when (type) {
                                        QuestionType.MCQ -> 2
                                        QuestionType.SHORT -> 3
                                        QuestionType.ESSAY -> 5
                                        QuestionType.MATCH -> 4
                                        QuestionType.TRUE_FALSE -> 3
                                        QuestionType.DRAW -> 4
                                        else -> 2
                                    }
                                )
                                questions.add(newItem)
                                showAddQuestionSheet = false
                                coroutineScope.launch {
                                    listState.animateScrollToItem(questions.size)
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(text = type.icon, fontSize = 20.sp)
                            Column {
                                Text(
                                    text = type.titleSi,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = DeepEspresso
                                )
                                Text(
                                    text = when (type) {
                                        QuestionType.MCQ -> "විකල්ප 4කින් නිවැරදි පිළිතුර තේරීම"
                                        QuestionType.SHORT -> "පේළි 2-5 අතර කෙටි පිළිතුරු"
                                        QuestionType.ESSAY -> "දීර්ඝ ලේඛන රචනා අවකාශය"
                                        QuestionType.FILL -> "වාක්‍යයේ හිස්තැන් පිරවීම"
                                        QuestionType.MATCH -> "A හා B තීර අතර ගළපා ලිවීම"
                                        QuestionType.TRUE_FALSE -> "ඇත හෝ නැත සලකුණු කිරීම"
                                        QuestionType.DRAW -> "ඩිජිටල් කැන්වසය මත රූප ඇඳීම"
                                        QuestionType.IMAGE -> "රූප සටහන් ඇතුළත් කිරීම"
                                    },
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // School Branding Dialog
    if (showBrandingDialog) {
        SchoolBrandingDialog(
            metadata = metadata,
            onDismiss = { showBrandingDialog = false },
            onSave = {
                metadata = it
                Toast.makeText(context, "පාසල් තොරතුරු සහ ලාංඡනය යාවත්කාලීන කෙරිණි", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Clear Answers Dialog
    if (showClearAnswersDialog) {
        ClearAnswersDialog(
            onDismiss = { showClearAnswersDialog = false },
            onClearAll = {
                // Clear MCQ and True/False answers
                questions.forEachIndexed { idx, q ->
                    questions[idx] = q.copy(
                        correctOption = null,
                        tfAnswers = q.tfAnswers.map { null }
                    )
                }
                Toast.makeText(context, "සියලු පිළිතුරු ඉවත් කර පිරිසිදු පත්‍රිකාවක් සකස් කරන ලදී", Toast.LENGTH_SHORT).show()
            },
            onClearMcqOnly = {
                questions.forEachIndexed { idx, q ->
                    if (q.type == QuestionType.MCQ) {
                        questions[idx] = q.copy(correctOption = null)
                    }
                }
                Toast.makeText(context, "MCQ පිළිතුරු ඉවත් කෙරිණි", Toast.LENGTH_SHORT).show()
            },
            onClearWrittenOnly = {
                questions.forEachIndexed { idx, q ->
                    if (q.type == QuestionType.TRUE_FALSE) {
                        questions[idx] = q.copy(tfAnswers = q.tfAnswers.map { null })
                    }
                }
                Toast.makeText(context, "ලිඛිත සලකුණු ඉවත් කෙරිණි", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
private fun StatBadge(label: String, count: Int) {
    Surface(
        color = Color.White.copy(alpha = 0.15f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = "$count", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AcademicGold)
            Text(text = label, fontSize = 11.sp, color = Color.White)
        }
    }
}

@Composable
private fun SubjectChip(title: String, onClick: () -> Unit) {
    Surface(
        color = StoneBackground2,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = "+ $title",
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = AcademicNavy,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
