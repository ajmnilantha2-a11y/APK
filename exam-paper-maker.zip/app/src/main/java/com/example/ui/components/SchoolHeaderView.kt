package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ExamMetadata
import com.example.model.LogoHeaderStyle
import com.example.ui.theme.AcademicGold
import com.example.ui.theme.AcademicNavy
import com.example.ui.theme.AcademicNavyDark
import com.example.ui.theme.DeepEspresso
import com.example.ui.theme.PaperBackground
import com.example.ui.theme.PaperBorder
import com.example.ui.theme.StoneBackground2
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SchoolHeaderView(
    metadata: ExamMetadata,
    onUpdateMetadata: (ExamMetadata) -> Unit,
    onOpenBrandingDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("school_header_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PaperBackground),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, PaperBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Top Bar with quick badge & customization trigger
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = AcademicNavy.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.clickable { onOpenBrandingDialog() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (metadata.showLogo) Color(0xFF16A34A) else Color.Gray)
                        )
                        Text(
                            text = if (metadata.showLogo) "පාසල් ලාංඡනය සක්‍රියයි" else "ලාංඡනය අක්‍රියයි",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = AcademicNavy
                        )
                    }
                }

                Surface(
                    color = AcademicGold.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .clickable { onOpenBrandingDialog() }
                        .testTag("edit_branding_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit School Branding",
                            modifier = Modifier.size(13.dp),
                            tint = Color(0xFF854D0E)
                        )
                        Text(
                            text = "සැකසුම් & ලාංඡනය",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF854D0E)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Display Logo according to chosen style
            AnimatedVisibility(visible = metadata.showLogo) {
                when (metadata.logoStyle) {
                    LogoHeaderStyle.CENTER_CREST -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .padding(bottom = 12.dp)
                                .clickable { onOpenBrandingDialog() }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .shadow(6.dp, CircleShape)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .border(2.5.dp, AcademicGold, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.app_logo_crest),
                                    contentDescription = "Official School Crest",
                                    modifier = Modifier
                                        .size(68.dp)
                                        .testTag("school_crest_logo"),
                                    contentScale = ContentScale.Fit
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "නිල ලාංඡනය",
                                fontSize = 10.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    LogoHeaderStyle.SIDE_BADGE -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .padding(bottom = 8.dp)
                                .clickable { onOpenBrandingDialog() }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .shadow(3.dp, CircleShape)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .border(2.dp, AcademicGold, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.app_logo_crest),
                                    contentDescription = "Official School Crest",
                                    modifier = Modifier.size(46.dp),
                                    contentScale = ContentScale.Fit
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = metadata.schoolName,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AcademicNavy
                                )
                                Text(
                                    text = metadata.examTitle,
                                    fontSize = 13.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    LogoHeaderStyle.HEADER_BANNER -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(AcademicNavyDark, AcademicNavy, AcademicNavyDark)
                                    )
                                )
                                .padding(vertical = 10.dp, horizontal = 16.dp)
                                .clickable { onOpenBrandingDialog() },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                        .border(1.5.dp, AcademicGold, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.app_logo_crest),
                                        contentDescription = "School Logo",
                                        modifier = Modifier.size(42.dp),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text(
                                        text = metadata.schoolName,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = metadata.examTitle,
                                        fontSize = 12.sp,
                                        color = AcademicGold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // If not side badge or banner, display centered titles
            if (metadata.logoStyle == LogoHeaderStyle.CENTER_CREST || !metadata.showLogo) {
                // School Name (editable directly)
                BasicTextField(
                    value = metadata.schoolName,
                    onValueChange = { onUpdateMetadata(metadata.copy(schoolName = it)) },
                    textStyle = TextStyle(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = AcademicNavy,
                        textAlign = TextAlign.Center,
                        fontFamily = FontFamily.Serif
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("school_name_input"),
                    decorationBox = { innerTextField ->
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (metadata.schoolName.isEmpty()) {
                                Text(
                                    text = "පාසලේ නම ඇතුළත් කරන්න",
                                    fontSize = 18.sp,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                Spacer(modifier = Modifier.height(3.dp))

                // Exam Title
                BasicTextField(
                    value = metadata.examTitle,
                    onValueChange = { onUpdateMetadata(metadata.copy(examTitle = it)) },
                    textStyle = TextStyle(
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D5AA0),
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { innerTextField ->
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (metadata.examTitle.isEmpty()) {
                                Text(
                                    text = "විභාග ශීර්ෂය",
                                    fontSize = 14.sp,
                                    color = Color.Gray
                                )
                            }
                            innerTextField()
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Decorative double rule line representing standard government exam paper format
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(AcademicNavy)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(AcademicNavy.copy(alpha = 0.5f))
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata info badges (Date, Duration, Marks, Subject)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                InfoTag(icon = Icons.Default.DateRange, label = metadata.examDate)
                Spacer(modifier = Modifier.width(6.dp))
                InfoTag(icon = Icons.Default.Timer, label = metadata.duration)
                Spacer(modifier = Modifier.width(6.dp))
                InfoTag(icon = Icons.Default.Star, label = "${metadata.totalMarks} ලකුණු")
                Spacer(modifier = Modifier.width(6.dp))
                InfoTag(icon = Icons.Default.MenuBook, label = metadata.subject)
            }
        }
    }
}

@Composable
private fun InfoTag(icon: ImageVector, label: String) {
    Surface(
        color = StoneBackground2,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(13.dp),
                tint = AcademicNavy
            )
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = DeepEspresso
            )
        }
    }
}
