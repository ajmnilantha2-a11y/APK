package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AcademicNavy = Color(0xFF1A3A6B)
val AcademicNavyDark = Color(0xFF0F2447)
val AcademicNavyLight = Color(0xFF2D5AA0)

val AcademicGold = Color(0xFFD4A017)
val AcademicGoldLight = Color(0xFFF0C842)
val AcademicGoldContainer = Color(0xFFFFF4D1)

val PaperBackground = Color(0xFFFDFAF4)
val StoneBackground = Color(0xFFF5F0E8)
val StoneBackground2 = Color(0xFFECE5D8)
val PaperBorder = Color(0xFFB8A88A)

val DeepEspresso = Color(0xFF2C1A0E)
val TextSecondary = Color(0xFF5A4A3A)

val CorrectGreen = Color(0xFF1A7A3C)
val CorrectGreenBg = Color(0xFFDCFCE7)

val ErrorRed = Color(0xFFDC2626)
val ErrorRedBg = Color(0xFFFEE2E2)
