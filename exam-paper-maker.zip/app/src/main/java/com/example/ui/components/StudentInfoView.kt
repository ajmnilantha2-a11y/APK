package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExamMetadata
import com.example.ui.theme.AcademicNavy
import com.example.ui.theme.DeepEspresso
import com.example.ui.theme.PaperBackground
import com.example.ui.theme.PaperBorder
import com.example.ui.theme.StoneBackground
import com.example.ui.theme.StoneBackground2
import com.example.ui.theme.TextSecondary

@Composable
fun StudentInfoView(
    metadata: ExamMetadata,
    onUpdateMetadata: (ExamMetadata) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        // Student Info Grid
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = StoneBackground2.copy(alpha = 0.5f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StudentInfoField(
                        label = "නම:",
                        value = metadata.studentName,
                        onValueChange = { onUpdateMetadata(metadata.copy(studentName = it)) },
                        modifier = Modifier.weight(1.5f),
                        placeholder = "ශිෂ්‍යයාගේ නම"
                    )
                    StudentInfoField(
                        label = "ශ්‍රේණිය:",
                        value = metadata.grade,
                        onValueChange = { onUpdateMetadata(metadata.copy(grade = it)) },
                        modifier = Modifier.weight(1f),
                        placeholder = "5 ශ්‍රේණිය"
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StudentInfoField(
                        label = "ශිෂ්‍ය අංකය:",
                        value = metadata.studentIndex,
                        onValueChange = { onUpdateMetadata(metadata.copy(studentIndex = it)) },
                        modifier = Modifier.weight(1.2f),
                        placeholder = "අංකය"
                    )
                    StudentInfoField(
                        label = "දිනය:",
                        value = metadata.examDate,
                        onValueChange = { onUpdateMetadata(metadata.copy(examDate = it)) },
                        modifier = Modifier.weight(1f),
                        placeholder = "දිනය"
                    )
                    StudentInfoField(
                        label = "ලකුණු:",
                        value = "",
                        onValueChange = {},
                        modifier = Modifier.weight(0.8f),
                        placeholder = "/100",
                        readOnly = true
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Instructions banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9DB)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFE082))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Instructions",
                    modifier = Modifier.size(18.dp),
                    tint = Color(0xFFB45309)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "උපදෙස්:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF92400E)
                    )
                    BasicTextField(
                        value = metadata.instructions,
                        onValueChange = { onUpdateMetadata(metadata.copy(instructions = it)) },
                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            color = Color(0xFF78350F),
                            lineHeight = 16.sp
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun StudentInfoField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    readOnly: Boolean = false
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.padding(start = 4.dp))
        Box(
            modifier = Modifier
                .weight(1f)
                .height(26.dp)
                .drawBehind {
                    val strokeWidth = 1.dp.toPx()
                    val y = size.height - strokeWidth / 2
                    drawLine(
                        color = Color(0xFFB8A88A),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = strokeWidth
                    )
                },
            contentAlignment = Alignment.CenterStart
        ) {
            if (value.isEmpty()) {
                Text(
                    text = placeholder,
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
            }
            if (!readOnly) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    textStyle = TextStyle(
                        fontSize = 12.sp,
                        color = DeepEspresso,
                        fontWeight = FontWeight.Medium
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        }
    }
}
