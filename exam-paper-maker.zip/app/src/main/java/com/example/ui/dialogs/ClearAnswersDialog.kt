package com.example.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.AcademicNavy
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PaperBackground
import com.example.ui.theme.TextSecondary

@Composable
fun ClearAnswersDialog(
    onDismiss: () -> Unit,
    onClearAll: () -> Unit,
    onClearMcqOnly: () -> Unit,
    onClearWrittenOnly: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PaperBackground),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.CleaningServices,
                    contentDescription = null,
                    tint = AcademicNavy,
                    modifier = Modifier.size(36.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "පිළිතුරු ඉවත් කිරීම",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = AcademicNavy
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "ගුරුභවතුන් විසින් සලකුණු කරන ලද නිවැරදි පිළිතුරු හෝ සිසුන්ගේ පිළිතුරු ඉවත් කර පිරිසිදු ප්‍රශ්න පත්‍රයක් සැකසීමට තෝරන්න.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onClearAll()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🗑️ සියලු පිළිතුරු ඉවත් කරන්න (පිරිසිදු පත්‍රිකාව)")
                    }

                    Button(
                        onClick = {
                            onClearMcqOnly()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AcademicNavy),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🔵 MCQ පිළිතුරු පමණක් ඉවත් කරන්න")
                    }

                    Button(
                        onClick = {
                            onClearWrittenOnly()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CorrectGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("✏️ ලිඛිත / ගළපා පිළිතුරු ඉවත් කරන්න")
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("අවලංගු කරන්න", color = TextSecondary)
                    }
                }
            }
        }
    }
}
