package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.R
import com.example.model.ExamMetadata
import com.example.model.LogoHeaderStyle
import com.example.model.QuestionItem
import com.example.model.QuestionType
import java.io.ByteArrayOutputStream

object PrintHelper {

    fun printExamPaper(
        context: Context,
        metadata: ExamMetadata,
        questions: List<QuestionItem>,
        isAnswerKey: Boolean = false
    ) {
        val logoBase64 = getLogoBase64(context)

        val htmlContent = generateHtml(
            metadata = metadata,
            questions = questions,
            logoBase64 = logoBase64,
            isAnswerKey = isAnswerKey
        )

        val webView = WebView(context)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val printAdapter = webView.createPrintDocumentAdapter("Scholarship_Exam_Paper")
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()

                printManager?.print("5_Scholarship_Exam_Paper", printAdapter, printAttributes)
            }
        }

        webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
    }

    private fun getLogoBase64(context: Context): String {
        return try {
            val bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.app_logo_crest)
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    private fun generateHtml(
        metadata: ExamMetadata,
        questions: List<QuestionItem>,
        logoBase64: String,
        isAnswerKey: Boolean
    ): String {
        val sinhalaLetters = listOf("අ", "ආ", "ඇ", "ඈ", "ඉ", "ඊ")

        val questionsHtml = StringBuilder()
        var questionNumber = 0

        questions.forEach { q ->
            if (q.isSection) {
                questionsHtml.append("""
                    <div style="background:#1a3a6b;color:#ffffff;padding:8px 14px;font-size:14pt;font-weight:bold;margin:18px 0 12px;border-radius:4px;font-family:'Noto Serif Sinhala',serif;">
                        ${q.sectionTitle}
                    </div>
                """.trimIndent())
                return@forEach
            }

            questionNumber++
            questionsHtml.append("""
                <div style="page-break-inside:avoid;margin-bottom:14px;border:1px solid #d4c8b8;border-radius:6px;padding:12px;background:#ffffff;">
                    <div style="display:flex;align-items:center;margin-bottom:8px;">
                        <span style="background:#1a3a6b;color:#ffffff;border-radius:50%;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-weight:bold;font-size:10pt;margin-right:8px;">
                            $questionNumber
                        </span>
                        <span style="font-size:11.5pt;font-family:'Noto Serif Sinhala',serif;flex:1;color:#2c1a0e;">
                            ${q.question}
                        </span>
                        <span style="font-size:10pt;font-weight:bold;color:#5a4a3a;margin-left:8px;">
                            [ලකුණු ${q.marks}]
                        </span>
                    </div>
            """.trimIndent())

            when (q.type) {
                QuestionType.MCQ -> {
                    questionsHtml.append("""<div style="margin-left:32px;display:grid;grid-template-columns:1fr 1fr;gap:6px;">""")
                    q.options.forEachIndexed { i, opt ->
                        val isCorrect = isAnswerKey && q.correctOption == i
                        val letter = sinhalaLetters.getOrElse(i) { (i + 1).toString() }
                        val bg = if (isCorrect) "#dcfce7" else "#fafafa"
                        val border = if (isCorrect) "#16a34a" else "#e5e7eb"
                        val checkmark = if (isCorrect) " ✓" else ""
                        questionsHtml.append("""
                            <div style="padding:4px 8px;border:1px solid $border;background:$bg;border-radius:4px;font-size:10.5pt;">
                                <strong>($letter)</strong> $opt <strong>$checkmark</strong>
                            </div>
                        """.trimIndent())
                    }
                    questionsHtml.append("</div>")
                }

                QuestionType.SHORT, QuestionType.ESSAY -> {
                    questionsHtml.append("""<div style="margin-top:8px;margin-left:32px;">""")
                    for (i in 0 until q.lines) {
                        questionsHtml.append("""<div style="border-bottom:1px dashed #b8a88a;height:22px;width:100%;"></div>""")
                    }
                    questionsHtml.append("</div>")
                }

                QuestionType.FILL -> {
                    questionsHtml.append("""<div style="margin-top:6px;margin-left:32px;font-size:10.5pt;color:#6b7280;font-style:italic;">පිළිතුර ඉහත හිස්තැනෙහි ලියන්න.</div>""")
                }

                QuestionType.MATCH -> {
                    questionsHtml.append("""
                        <div style="display:grid;grid-template-columns:1fr 40px 1fr;gap:8px;margin-left:32px;margin-top:6px;font-size:10pt;">
                            <div style="font-weight:bold;color:#1a3a6b;">A තීරය</div>
                            <div></div>
                            <div style="font-weight:bold;color:#d4a017;">B තීරය</div>
                    """.trimIndent())

                    q.matchLeft.indices.forEach { i ->
                        val leftText = q.matchLeft.getOrElse(i) { "" }
                        val rightText = q.matchRight.getOrElse(i) { "" }
                        val rightLetter = listOf("A", "B", "C", "D", "E").getOrElse(i) { (i + 1).toString() }
                        questionsHtml.append("""
                            <div>${i + 1}. $leftText</div>
                            <div style="border-bottom:1px solid #777;text-align:center;">&nbsp;</div>
                            <div>($rightLetter) $rightText</div>
                        """.trimIndent())
                    }
                    questionsHtml.append("</div>")
                }

                QuestionType.TRUE_FALSE -> {
                    questionsHtml.append("""<div style="margin-left:32px;margin-top:6px;">""")
                    q.statements.forEachIndexed { i, stmt ->
                        val ans = if (isAnswerKey) {
                            when (q.tfAnswers.getOrElse(i) { null }) {
                                true -> " [ඇත ✓]"
                                false -> " [නැත ✓]"
                                null -> " [ ...... ]"
                            }
                        } else {
                            " [ ...... ]"
                        }
                        questionsHtml.append("""
                            <div style="display:flex;justify-content:space-between;padding:3px 0;font-size:10.5pt;">
                                <span>${i + 1}. $stmt</span>
                                <span style="font-weight:bold;color:#1a3a6b;">$ans</span>
                            </div>
                        """.trimIndent())
                    }
                    questionsHtml.append("</div>")
                }

                QuestionType.DRAW -> {
                    questionsHtml.append("""
                        <div style="margin-left:32px;margin-top:8px;height:120px;border:1.5px dashed #b8a88a;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#9ca3af;font-size:10pt;">
                            [ රූප සටහන ඇඳීමට ඇති ඉඩකඩ ]
                        </div>
                    """.trimIndent())
                }

                QuestionType.IMAGE -> {
                    questionsHtml.append("""
                        <div style="margin-left:32px;margin-top:6px;text-align:center;">
                            <div style="padding:10px;border:1px solid #ddd;display:inline-block;border-radius:4px;background:#fafafa;">
                                [ රූප සටහන ]
                            </div>
                        </div>
                    """.trimIndent())
                }
            }

            questionsHtml.append("</div>")
        }

        val logoHtml = if (metadata.showLogo && logoBase64.isNotEmpty()) {
            """
            <div style="text-align:center;margin-bottom:8px;">
                <img src="data:image/png;base64,$logoBase64" style="height:65px;width:65px;object-fit:contain;border-radius:50%;border:2px solid #d4a017;padding:2px;background:#fff;" alt="School Logo" />
            </div>
            """.trimIndent()
        } else ""

        val answerKeyBadge = if (isAnswerKey) {
            """<div style="background:#fee2e2;color:#dc2626;padding:4px 10px;font-weight:bold;font-size:11pt;border-radius:4px;display:inline-block;margin-bottom:8px;">⚠️ ගුරු පිළිතුරු පත්‍රිකාව (Teacher's Answer Key)</div>"""
        } else ""

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>${metadata.schoolName} - ${metadata.examTitle}</title>
                <style>
                    @page { size: A4; margin: 15mm 15mm 15mm 15mm; }
                    body { font-family: 'Noto Sans Sinhala', 'Segoe UI', Arial, sans-serif; color: #2c1a0e; margin: 0; padding: 0; }
                    .header-box { text-align: center; border-bottom: 3px double #1a3a6b; padding-bottom: 10px; margin-bottom: 12px; }
                    .school-title { font-size: 18pt; font-weight: bold; color: #1a3a6b; margin: 2px 0; }
                    .exam-title { font-size: 12pt; color: #2d5aa0; margin: 2px 0; }
                    .meta-row { display: flex; justify-content: center; gap: 16px; font-size: 10pt; margin-top: 6px; }
                    .student-table { width: 100%; border-collapse: collapse; margin-bottom: 12px; font-size: 9.5pt; border: 1px solid #b8a88a; background: #fdfaf4; }
                    .student-table td { padding: 5px 8px; border: 1px solid #b8a88a; }
                    .instruction-box { background: #fff8e1; border: 1px solid #ffe082; padding: 6px 10px; border-radius: 4px; font-size: 9.5pt; color: #78350f; margin-bottom: 14px; }
                </style>
            </head>
            <body>
                <div class="header-box">
                    $answerKeyBadge
                    $logoHtml
                    <div class="school-title">${metadata.schoolName}</div>
                    <div class="exam-title">${metadata.examTitle}</div>
                    <div class="meta-row">
                        <span>📅 දිනය: <strong>${metadata.examDate}</strong></span>
                        <span>⏱️ කාලය: <strong>${metadata.duration}</strong></span>
                        <span>🏆 මුළු ලකුණු: <strong>${metadata.totalMarks}</strong></span>
                        <span>📚 විෂය: <strong>${metadata.subject}</strong></span>
                    </div>
                </div>

                <table class="student-table">
                    <tr>
                        <td style="width:50%;">නම: ________________________________</td>
                        <td style="width:25%;">ශ්‍රේණිය: ${metadata.grade}</td>
                        <td style="width:25%;">ලකුණු: ________</td>
                    </tr>
                    <tr>
                        <td>ශිෂ්‍ය අංකය: _____________________</td>
                        <td colspan="2">ගුරු අත්සන: _____________________</td>
                    </tr>
                </table>

                <div class="instruction-box">
                    <strong>උපදෙස්:</strong> ${metadata.instructions}
                </div>

                <div class="questions-container">
                    $questionsHtml
                </div>
            </body>
            </html>
        """.trimIndent()
    }
}
