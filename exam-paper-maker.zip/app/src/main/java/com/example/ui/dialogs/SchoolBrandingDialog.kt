package com.example.ui.dialogs

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.ExamMetadata
import com.example.model.LogoHeaderStyle
import com.example.ui.theme.AcademicGold
import com.example.ui.theme.AcademicNavy
import com.example.ui.theme.DeepEspresso
import com.example.ui.theme.PaperBackground
import com.example.ui.theme.PaperBorder
import com.example.ui.theme.StoneBackground2
import com.example.ui.theme.TextSecondary

@Composable
fun SchoolBrandingDialog(
    metadata: ExamMetadata,
    onDismiss: () -> Unit,
    onSave: (ExamMetadata) -> Unit
) {
    var currentMetadata by remember { mutableStateOf(metadata) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 24.dp)
                .testTag("school_branding_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperBackground),
            border = androidx.compose.foundation.BorderStroke(2.dp, AcademicGold)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = AcademicNavy,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "පාසල් ලාංඡනය & තොරතුරු",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AcademicNavy
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Logo Showcase Banner
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StoneBackground2,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .shadow(4.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(2.dp, AcademicGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.app_logo_crest),
                                contentDescription = "School Logo Emblem",
                                modifier = Modifier
                                    .size(54.dp)
                                    .testTag("dialog_logo_image"),
                                contentScale = ContentScale.Fit
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = AcademicNavy,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "නිල ලාංඡනය ඇතුළත් කර ඇත",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AcademicNavy
                                )
                            }
                            Text(
                                text = "මෙම ලාංඡනය යෙදුමේ අයිකනය, ප්‍රධාන ශීර්ෂය සහ A4 මුද්‍රණ පත්‍රිකාවේ විදහා දැක්වේ.",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggle Show Logo
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, PaperBorder, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "ප්‍රශ්න පත්‍රයේ ලාංඡනය පෙන්වන්න",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = DeepEspresso
                        )
                        Text(
                            text = "ශීර්ෂයේ සහ මුද්‍රණයේ ලාංඡනය දර්ශනය වේ",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = currentMetadata.showLogo,
                        onCheckedChange = { currentMetadata = currentMetadata.copy(showLogo = it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = AcademicNavy
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Logo Placement Styles
                Text(
                    text = "ශීර්ෂයේ ලාංඡන රටාව:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = AcademicNavy
                )
                Spacer(modifier = Modifier.height(6.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    LogoHeaderStyle.entries.forEach { style ->
                        val isSelected = currentMetadata.logoStyle == style
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) AcademicNavy.copy(alpha = 0.1f) else Color.White,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) AcademicNavy else PaperBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { currentMetadata = currentMetadata.copy(logoStyle = style) }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .border(2.dp, AcademicNavy, CircleShape)
                                        .background(if (isSelected) AcademicNavy else Color.Transparent)
                                )
                                Text(
                                    text = style.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) AcademicNavy else DeepEspresso
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Editable Fields
                OutlinedTextField(
                    value = currentMetadata.schoolName,
                    onValueChange = { currentMetadata = currentMetadata.copy(schoolName = it) },
                    label = { Text("පාසලේ නම") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = currentMetadata.examTitle,
                    onValueChange = { currentMetadata = currentMetadata.copy(examTitle = it) },
                    label = { Text("විභාග ශීර්ෂය") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = currentMetadata.subject,
                        onValueChange = { currentMetadata = currentMetadata.copy(subject = it) },
                        label = { Text("විෂය") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = currentMetadata.grade,
                        onValueChange = { currentMetadata = currentMetadata.copy(grade = it) },
                        label = { Text("ශ්‍රේණිය") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = currentMetadata.examDate,
                        onValueChange = { currentMetadata = currentMetadata.copy(examDate = it) },
                        label = { Text("දිනය") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = currentMetadata.duration,
                        onValueChange = { currentMetadata = currentMetadata.copy(duration = it) },
                        label = { Text("කාලය") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = currentMetadata.totalMarks.toString(),
                        onValueChange = {
                            currentMetadata = currentMetadata.copy(totalMarks = it.toIntOrNull() ?: 100)
                        },
                        label = { Text("මුළු ලකුණු") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("අවලංගු කරන්න", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            onSave(currentMetadata)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AcademicNavy),
                        modifier = Modifier.testTag("save_branding_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("සුරකින්න")
                    }
                }
            }
        }
    }
}
