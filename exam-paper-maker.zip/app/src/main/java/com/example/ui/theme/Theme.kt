package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = AcademicNavy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E2FF),
    onPrimaryContainer = Color(0xFF001A42),
    secondary = AcademicGold,
    onSecondary = DeepEspresso,
    secondaryContainer = AcademicGoldContainer,
    onSecondaryContainer = Color(0xFF5A4300),
    tertiary = CorrectGreen,
    onTertiary = Color.White,
    background = StoneBackground,
    onBackground = DeepEspresso,
    surface = PaperBackground,
    onSurface = DeepEspresso,
    surfaceVariant = StoneBackground2,
    onSurfaceVariant = TextSecondary,
    outline = PaperBorder,
    outlineVariant = Color(0xFFD4C8B8),
)

private val DarkColorScheme = darkColorScheme(
    primary = AcademicNavyLight,
    onPrimary = Color.White,
    primaryContainer = AcademicNavyDark,
    onPrimaryContainer = Color(0xFFD8E2FF),
    secondary = AcademicGoldLight,
    onSecondary = DeepEspresso,
    secondaryContainer = Color(0xFF423100),
    onSecondaryContainer = AcademicGoldContainer,
    tertiary = Color(0xFF4ADE80),
    onTertiary = Color.Black,
    background = Color(0xFF161A22),
    onBackground = Color(0xFFECE5D8),
    surface = Color(0xFF1E232E),
    onSurface = Color(0xFFF5F0E8),
    surfaceVariant = Color(0xFF2B313F),
    onSurfaceVariant = Color(0xFFC4CBD8),
    outline = Color(0xFF535D70),
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
