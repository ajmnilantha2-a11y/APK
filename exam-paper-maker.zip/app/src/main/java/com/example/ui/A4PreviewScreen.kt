package com.example.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ExamMetadata
import com.example.model.QuestionItem
import com.example.model.QuestionType
import com.example.ui.components.PrintHelper
import com.example.ui.components.SINHALA_LETTERS
import com.example.ui.theme.AcademicGold
import com.example.ui.theme.AcademicNavy
import com.example.ui.theme.AcademicNavyDark
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.DeepEspresso
import com.example.ui.theme.PaperBackground
import com.example.ui.theme.PaperBorder
import com.example.ui.theme.StoneBackground
import com.example.ui.theme.StoneBackground2
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun A4PreviewScreen(
    metadata: ExamMetadata,
    questions: List<QuestionItem>,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var isAnswerKeyMode by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.app_logo_crest),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                        )
                        Text("A4 මුද්‍රණ පෙරදසුන (A4 Preview)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    // Toggle Answer key vs Student exam
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isAnswerKeyMode) Color(0xFFFDE047) else Color.White.copy(alpha = 0.15f),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Button(
                            onClick = { isAnswerKeyMode = !isAnswerKeyMode },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            elevation = null
                        ) {
                            Text(
                                text = if (isAnswerKeyMode) "ගුරු පිළිතුරු" else "සිසු පත්‍රිකාව",
                                fontSize = 12.sp,
                                color = if (isAnswerKeyMode) Color.Black else Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Print / Save PDF Button
                    Button(
                        onClick = {
                            PrintHelper.printExamPaper(
                                context = context,
                                metadata = metadata,
                                questions = questions,
                                isAnswerKey = isAnswerKeyMode
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AcademicGold),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("print_button")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("මුද්‍රණය / PDF", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AcademicNavy,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = StoneBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            // A4 Paper Canvas representation
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = PaperBackground),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    // Answer Key banner if active
                    if (isAnswerKeyMode) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = "⚠️ ගුරු පිළිතුරු පත්‍රිකාව (TEACHER'S MARKING SCHEME)",
                                color = Color(0xFFDC2626),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(6.dp)
                            )
                        }
                    }

                    // A4 Header with LOGO in all its glory!
                    if (metadata.showLogo) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .shadow(4.dp, CircleShape)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .border(2.5.dp, AcademicGold, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.app_logo_crest),
                                    contentDescription = "School Logo Emblem",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .testTag("a4_preview_logo"),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }
                    }

                    // School Name
                    Text(
                        text = metadata.schoolName,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = AcademicNavy,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Exam Title
                    Text(
                        text = metadata.examTitle,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF2D5AA0),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Exam Meta Line
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("📅 ${metadata.examDate}  |  ⏱️ ${metadata.duration}  |  🏆 ${metadata.totalMarks} ලකුණු  |  📚 ${metadata.subject}", fontSize = 11.sp, color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Double line
                    Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(AcademicNavy))
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(AcademicNavy.copy(alpha = 0.5f)))

                    Spacer(modifier = Modifier.height(12.dp))

                    // Student Details Box
                    Surface(
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, PaperBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text("නම: _____________________________________", fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                                Text("ශ්‍රේණිය: ${metadata.grade}", fontSize = 11.sp, modifier = Modifier.weight(0.8f))
                                Text("ලකුණු: _______", fontSize = 11.sp, modifier = Modifier.weight(0.7f))
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text("ශිෂ්‍ය අංකය: __________________", fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                                Text("ගුරු අත්සන: __________________", fontSize = 11.sp, modifier = Modifier.weight(1f))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Instructions
                    Surface(
                        color = Color(0xFFFFFBEB),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "උපදෙස්: ${metadata.instructions}",
                            fontSize = 10.sp,
                            color = Color(0xFF92400E),
                            modifier = Modifier.padding(8.dp),
                            lineHeight = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Questions rendering
                    var questionIdx = 0
                    questions.forEach { q ->
                        if (q.isSection) {
                            Surface(
                                color = AcademicNavy,
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            ) {
                                Text(
                                    text = q.sectionTitle,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                            return@forEach
                        }

                        questionIdx++
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            // Question header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = "$questionIdx. ",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AcademicNavy
                                )
                                Text(
                                    text = q.question,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Serif,
                                    color = DeepEspresso,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "[ලකුණු ${q.marks}]",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextSecondary
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Question body
                            when (q.type) {
                                QuestionType.MCQ -> {
                                    Column(modifier = Modifier.padding(start = 18.dp)) {
                                        q.options.forEachIndexed { optIdx, optText ->
                                            val isCorrect = isAnswerKeyMode && q.correctOption == optIdx
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 2.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "(${SINHALA_LETTERS.getOrElse(optIdx) { (optIdx + 1).toString() }})  $optText",
                                                    fontSize = 11.sp,
                                                    color = if (isCorrect) CorrectGreen else DeepEspresso,
                                                    fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal
                                                )
                                                if (isCorrect) {
                                                    Text(" ✓ [නිවැරදියි]", fontSize = 11.sp, color = CorrectGreen, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }

                                QuestionType.SHORT, QuestionType.ESSAY -> {
                                    Column(modifier = Modifier.padding(start = 18.dp)) {
                                        for (i in 0 until q.lines) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(20.dp)
                                                    .drawBehind {
                                                        val strokeWidth = 1.dp.toPx()
                                                        val y = size.height - strokeWidth
                                                        drawLine(
                                                            color = Color(0xFFC0BFBE),
                                                            start = Offset(0f, y),
                                                            end = Offset(size.width, y),
                                                            strokeWidth = strokeWidth,
                                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                                                        )
                                                    }
                                            )
                                        }
                                    }
                                }

                                QuestionType.MATCH -> {
                                    Column(modifier = Modifier.padding(start = 18.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            Text("A තීරය", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                            Text("B තීරය", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        }
                                        q.matchLeft.indices.forEach { mIdx ->
                                            val left = q.matchLeft.getOrElse(mIdx) { "" }
                                            val right = q.matchRight.getOrElse(mIdx) { "" }
                                            val rLabel = listOf("A", "B", "C", "D").getOrElse(mIdx) { (mIdx + 1).toString() }
                                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                                                Text("${mIdx + 1}. $left  (.....)", fontSize = 11.sp, modifier = Modifier.weight(1f))
                                                Text("($rLabel) $right", fontSize = 11.sp, modifier = Modifier.weight(1f))
                                            }
                                        }
                                    }
                                }

                                QuestionType.TRUE_FALSE -> {
                                    Column(modifier = Modifier.padding(start = 18.dp)) {
                                        q.statements.forEachIndexed { sIdx, stmt ->
                                            val ans = if (isAnswerKeyMode) {
                                                when (q.tfAnswers.getOrElse(sIdx) { null }) {
                                                    true -> " [ඇත ✓]"
                                                    false -> " [නැත ✓]"
                                                    null -> " [ ...... ]"
                                                }
                                            } else " [ ...... ]"

                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("${sIdx + 1}. $stmt", fontSize = 11.sp)
                                                Text(ans, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AcademicNavy)
                                            }
                                        }
                                    }
                                }

                                else -> {
                                    Box(
                                        modifier = Modifier
                                            .padding(start = 18.dp)
                                            .fillMaxWidth()
                                            .height(80.dp)
                                            .border(1.dp, PaperBorder)
                                            .background(StoneBackground2.copy(alpha = 0.3f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("[ රූප සටහන හෝ පිළිතුර මෙහි දක්වන්න ]", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
