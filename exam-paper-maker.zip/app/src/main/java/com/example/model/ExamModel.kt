package com.example.model

import androidx.compose.ui.graphics.Color

enum class QuestionType(val titleSi: String, val icon: String) {
    MCQ("බහු තේරීම් (MCQ)", "🔵"),
    SHORT("කෙටි පිළිතුරු", "✏️"),
    ESSAY("රචනා ප්‍රශ්නය", "📝"),
    FILL("හිස් තැන් පිරවීම", "🔲"),
    MATCH("ගළපා ලිවීම", "🔗"),
    TRUE_FALSE("ඇත / නැත", "✅"),
    DRAW("රූප ඇඳීම / සටහන්", "🎨"),
    IMAGE("රූපය ඇතුළු කිරීම", "🖼️")
}

enum class LogoHeaderStyle(val label: String) {
    CENTER_CREST("මධ්‍යගත රාජකීය ලාංඡනය (Centered Crest)"),
    SIDE_BADGE("පැති ලාංඡනය (Side Crest Badge)"),
    HEADER_BANNER("සම්පූර්ණ ශීර්ෂ බැනරය (Banner Style)")
}

data class DrawPoint(val x: Float, val y: Float)

data class DrawStroke(
    val points: List<DrawPoint>,
    val color: Long,
    val strokeWidth: Float
)

data class QuestionItem(
    val id: String,
    val number: Int = 1,
    val type: QuestionType = QuestionType.SHORT,
    val isSection: Boolean = false,
    val sectionTitle: String = "",
    val question: String = "",
    val marks: Int = 2,
    val options: List<String> = listOf("", "", "", ""),
    val correctOption: Int? = null,
    val lines: Int = 3,
    val matchLeft: List<String> = listOf("", "", "", ""),
    val matchRight: List<String> = listOf("", "", "", ""),
    val matchAnswers: List<String> = listOf("", "", "", ""),
    val statements: List<String> = listOf("", "", ""),
    val tfAnswers: List<Boolean?> = listOf(null, null, null),
    val strokes: List<DrawStroke> = emptyList(),
    val imageCaption: String = ""
)

data class ExamMetadata(
    val schoolName: String = "ශ්‍රී ලංකා ජාතික පාසල",
    val examTitle: String = "5 ශ්‍රේණිය ශිෂ්‍යත්ව පෙරහුරු විභාගය",
    val grade: String = "5 ශ්‍රේණිය",
    val subject: String = "ගණිතය හා පරිසරය",
    val examDate: String = "2024.10.20",
    val duration: String = "පැය 2",
    val totalMarks: Int = 100,
    val instructions: String = "සෑම ප්‍රශ්නයකටම හොඳින් කියවා පිළිතුරු ලියන්න. බහුවරණ ප්‍රශ්නවල නිවැරදි පිළිතුර තෝරා අදාළ අංකය හෝ සලකුණ යොදන්න.",
    val showLogo: Boolean = true,
    val logoStyle: LogoHeaderStyle = LogoHeaderStyle.CENTER_CREST,
    val studentName: String = "",
    val studentIndex: String = "",
    val teacherSignature: String = ""
)
